document.addEventListener('keydown', (event) => {
  console.log('HDRezka Plugin: Key pressed:', event.key);

  // Логика для пробела (воспроизведение/пауза)
  if (event.key === ' ') {
    console.log('HDRezka Plugin: Spacebar pressed.');
    if (document.fullscreenElement) {
      console.log('HDRezka Plugin: Fullscreen mode detected.');
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation(); // Добавлено для более надежной остановки
      simulateClickAtCenter();
      console.log('HDRezka Plugin: Click simulation attempted.');
    } else {
      console.log('HDRezka Plugin: Not in fullscreen mode.');
    }
  }

  // Новая логика для PageDown (следующая серия)
  if (event.key === 'PageDown') {
    console.log('HDRezka Plugin: PageDown pressed.');
    // Немедленно предотвращаем стандартное поведение и останавливаем распространение
    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation(); // Добавлено для более надежной остановки

    const currentUrl = window.location.href;
    console.log('HDRezka Plugin: Current URL detected:', currentUrl);
    
    const episodeRegex = /-e:(\d+)/;
    const seasonRegex = /-s:(\d+)/; // Добавляем регулярное выражение для сезона

    const episodeMatch = currentUrl.match(episodeRegex);
    const seasonMatch = currentUrl.match(seasonRegex); // Ищем совпадение для сезона

    if (episodeMatch && episodeMatch[1] && seasonMatch && seasonMatch[1]) {
      const currentEpisode = parseInt(episodeMatch[1], 10);
      const currentSeason = parseInt(seasonMatch[1], 10); // Получаем текущий сезон
      const nextEpisode = currentEpisode + 1;
      console.log(`HDRezka Plugin: Current Season: ${currentSeason}, Current Episode: ${currentEpisode}, Next Episode: ${nextEpisode}`);

      // Обновляем селектор для поиска элементов списка эпизодов
      const allEpisodeItems = document.querySelectorAll('.b-simple_episode__item');
      console.log(`HDRezka Plugin: Found ${allEpisodeItems.length} episode items.`);
      let nextEpisodeLinkFound = false;

      for (const item of Array.from(allEpisodeItems)) {
        const episodeId = item.getAttribute('data-episode_id');
        const seasonId = item.getAttribute('data-season_id'); // Получаем ID сезона из элемента

        if (episodeId && seasonId &&
            parseInt(episodeId, 10) === nextEpisode &&
            parseInt(seasonId, 10) === currentSeason) { // Проверяем и ID эпизода, и ID сезона
          console.log(`HDRezka Plugin: Found item for episode ${nextEpisode} in season ${currentSeason}, attempting click.`);
          
          // Имитируем клик с небольшой задержкой для надежности
          setTimeout(() => {
            const clickEvent = new MouseEvent('click', {
              view: window,
              bubbles: true,
              cancelable: true,
              // Вычисляем центр элемента для более точной имитации клика
              clientX: item.getBoundingClientRect().left + item.getBoundingClientRect().width / 2,
              clientY: item.getBoundingClientRect().top + item.getBoundingClientRect().height / 2,
              button: 0 // Левая кнопка мыши
            });
            item.dispatchEvent(clickEvent);
            console.log('HDRezka Plugin: Click event dispatched for next episode item.');
          }, 50); // Небольшая задержка в 50 мс

          nextEpisodeLinkFound = true;
          break; // Выходим после первого найденного совпадения
        }
      }

      if (!nextEpisodeLinkFound) {
        console.warn(`HDRezka Plugin: Item for episode ${nextEpisode} in season ${currentSeason} not found. Attempting URL navigation fallback.`);
        // Если ссылка не найдена, возвращаемся к прямой навигации по URL
        const newUrl = currentUrl.replace(episodeRegex, `-e:${nextEpisode}`);
        window.location.replace(newUrl);
        console.log('HDRezka Plugin: Falling back to navigating to next episode URL:', newUrl);
      }
    } else {
      console.error('HDRezka Plugin: Could not find current episode or season number in URL for PageDown logic. No action taken. Current URL:', currentUrl);
    }
  }
}, true); // Используем фазу захвата (capture phase)

// Вспомогательная функция для имитации клика по центру экрана (из предыдущей реализации)
function simulateClickAtCenter() {
  const centerX = window.innerWidth / 2;
  const centerY = window.innerHeight / 2;
  const targetElement = document.elementFromPoint(centerX, centerY);

  if (targetElement) {
    console.log('HDRezka Plugin: Target element found for click:', targetElement);
    const clickEvent = new MouseEvent('click', {
      view: window,
      bubbles: true,
      cancelable: true,
      clientX: centerX,
      clientY: centerY,
      button: 0 // Левая кнопка мыши
    });
    targetElement.dispatchEvent(clickEvent);
    console.log('HDRezka Plugin: Click event dispatched.');
  } else {
    console.log('HDRezka Plugin: No suitable element found for click at center.');
  }
}
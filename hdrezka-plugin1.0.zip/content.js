document.addEventListener('keydown', (event) => {
  // Проверяем, что нажата клавиша пробел
  if (event.key === ' ') {
    // Проверяем, находится ли страница в полноэкранном режиме
    if (document.fullscreenElement) {
      // Предотвращаем стандартное действие пробела (например, прокрутку страницы)
      event.preventDefault();

      // Вычисляем центр экрана
      const centerX = window.innerWidth / 2;
      const centerY = window.innerHeight / 2;

      // Создаем событие клика
      const clickEvent = new MouseEvent('click', {
        view: window,
        bubbles: true,
        cancelable: true,
        clientX: centerX,
        clientY: centerY,
        button: 0 // Левая кнопка мыши
      });

      // Отправляем событие клика по центру экрана
      document.elementFromPoint(centerX, centerY)?.dispatchEvent(clickEvent);
    }
  }
});